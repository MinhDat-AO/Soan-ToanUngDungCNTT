x = 0
y = 0
d = 0
def euclid(a, b):
    global x,y,d
    if (b==0):
        d = a
        x = 1
        y = 0
    else:
        euclid(b,a%b)
        temp =int(x)
        x = y
        y = temp - (a//b)*y
    return d

a, b = map(int, input().split())
result = euclid(a,b)
print(result)
print(x)
print(y)