#include <bits/stdc++.h>
#define ll long long
#define endl '\n'
#define pll pair<long long,long long>
#define int long long
#define pii pair<int,int>
#define FOR(i,a,b) for(int i =a; i<=b; i++)
#define ROF(i,a,b) for(int i =a; i>=b; i--)

const long long MOD = 1e9+7;

using namespace std;

void solve(){
    int n = 15;
        cout<<"[";
    for (int i =1; i<=n; i++){
        cout<<"[";
        for (int j = 1; j<=n; j++){
            if (j == i-1) cout<<'2';
            else if (j==i) cout<<'5';
            else if (j==i+1) cout<<"2";
            else cout<<"0";
            if (j!=n) cout<<",";
        }
        cout<<"]\n";
    }
        cout<<"]";
}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(NULL);
    cout.tie(NULL);
        solve();
    return 0;
}