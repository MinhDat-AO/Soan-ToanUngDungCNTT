is_prime = [True]*((int)(1e6))

def sieve():
    is_prime[0]=False
    is_prime[1]=False
    for i in range(2,(int)(1e6)):
        if is_prime[i] == False: 
            continue
        # print(i)
        for j in range (i*i,int(1e6),i):
            is_prime[j]= False
sieve()
print(is_prime[7])

