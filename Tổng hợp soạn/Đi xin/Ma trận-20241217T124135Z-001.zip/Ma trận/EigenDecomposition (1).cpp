#include <iostream>
#include <Eigen/Dense>

using namespace std;
using namespace Eigen;

void GetEigenVector(const MatrixXd& x, MatrixXd &vector)
{
    SelfAdjointEigenSolver<Eigen::MatrixXd> eigensolver(x);
    vector = eigensolver.eigenvectors();
}

MatrixXd CoFactor(const MatrixXd& A, int p, int q)
{
    int n = A.cols();
    MatrixXd temp(n, n);
    int i = 0, j = 0;
    for (int row = 0; row < n; row++) {
        for (int col = 0; col < n; col++) {
            if (row != p && col != q) {
                temp(i, j++) = A(row, col);
                if (j == n - 1) {
                    j = 0;
                    i++;
                }
            }
        }
    }
    return temp;
}

double determinant(const MatrixXd& A, int n)
{
    double D = 0;
    if (n == 1)
        return A(0, 0);
    MatrixXd temp(n, n);
    double sign = 1;
    for (int f = 0; f < n; f++) {
        temp = CoFactor(A, 0, f);
        D += sign * A(0, f) * determinant(temp, n - 1);
        sign = -sign;
    }
    return D;
}

MatrixXd LienHop(const MatrixXd& A)
{
    int N = A.cols();
    MatrixXd adj(N, N);
    if (N == 1) {
        adj(0, 0) = 1;
        return adj;
    }
    int sign = 1;
    MatrixXd temp(N, N);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            temp = CoFactor(A, i, j);
            sign = ((i + j) % 2 == 0) ? 1 : -1;
            adj(j, i) = (sign) * (determinant(temp, N - 1));
        }
    }
    return adj;
}

MatrixXd nghichdao(const MatrixXd& A)
{
    int N = A.cols();
    MatrixXd nghichdao(N, N);
    double det = determinant(A, N);
    if (det == 0) {
        cout << "Singular matrix, can't find its nghichdao";
    }
    else{
        MatrixXd adj(N, N);
        adj = LienHop(A);
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                nghichdao(i, j) = adj(i, j) / det;
        return nghichdao;
    }
}

int main(){
    int n;
    cout << "Nhap so chieu cua ma tran A ";
    cin >> n;
    MatrixXd A(n, n);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++){
            cout << "A(" << i << "," << j << ") = ";
            cin >> A(i, j);
        }
    cout << "A = \n" << A << endl;
    MatrixXd P(n, n);
    GetEigenVector(A, P);
    MatrixXd P_inv = nghichdao(P), D;
    D = P_inv * A * P;
    cout << "Ma tran A = P * D * P_inv, trong do: " << endl;
    cout << "P = \n" << P << endl;
    cout << "D = \n" << D << endl;
    cout << " P_inv = \n" << P_inv << endl;
    cout << "Thu lai " << endl;
    MatrixXd temp = P * D * P_inv;
    cout << " A = P * D * P_inv = \n" << temp;
}