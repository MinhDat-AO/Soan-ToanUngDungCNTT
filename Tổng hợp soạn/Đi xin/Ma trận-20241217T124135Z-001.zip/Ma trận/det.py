import numpy as np

def is_square_matrix(matrix):
    rows, cols = matrix.shape
    return rows == cols

def tinh_dinh_thuc(matrix):
    # Kiểm tra kích thước của ma trận
    rows, cols = matrix.shap
    if not is_square_matrix(matrix):
        raise ValueError("Ma trận không phải là ma trận vuông")
    if rows == 1:
        return matrix[0][0]
    determinant = 0
    for col in range(cols):
        sub_matrix = np.delete(matrix, col, axis=1)[1:]
        sub_determinant = tinh_dinh_thuc(sub_matrix)
        determinant += matrix[0][col] * sub_determinant * (-1) ** col
    
    return determinant

def nhap_ma_tran():
    while True:
        n = int(input("Nhập số hàng của ma trận: "))
        m = int(input("Nhập số cột của ma trận: "))
        if n <= 0 or m <= 0:
            print("Vui lòng nhập một số nguyên dương.")
        else:
            break

    matrix = np.zeros((n, m))

    print("Nhập các phần tử của ma trận:")
    for i in range(n):
        for j in range(m):
            while True:
                try:
                    matrix[i, j] = float(input(f"Nhập phần tử ({i+1}, {j+1}): "))
                    break
                except ValueError:
                    print("Vui lòng nhập một số.")

    return matrix

matrix = nhap_ma_tran()

print("Ma trận vừa nhập:")
print(matrix)

determinant = tinh_dinh_thuc(matrix)
print("Định thức của ma trận:", determinant)