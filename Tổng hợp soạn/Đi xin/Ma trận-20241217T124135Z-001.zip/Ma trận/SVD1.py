import numpy as np

A = np.array([
    [5,5,0,1],
    [4,5,0,0],
    [1,0,5,4]
])

def eigenvector(n, B, inp):
    res = []
    for i in range(0,n):
        sum = 0
        for j in range(0,n):
            sum += B[i,j]*inp[j]
        res.append(sum)
    return np.array(res)

def eigenvalue_decomposition(input):
    n = input.shape[0]
    B = np.zeros(input.shape)
    for i in range (0,n):
        B[i,i] = 1
    M = np.zeros(input.shape)
    M_1 = np.zeros(input.shape)

    A = np.copy(input)
    for k in range(n-2,-1,-1):
        for i in range(0,n):
            for j in range(0,n):
                if (i!=k):
                    if (i==j):
                        M[i,j] = 1
                        M_1[i,j] = 1
                    else:
                        M[i,j] = 0
                        M_1[i,j] = 0
                else:
                    M_1[i,j] = A[k+1,j]
                    if (j==k):
                        M[i,j] = 1/A[k+1,k]
                    else:
                        M[i,j] = -A[k+1,j]/A[k+1,k]
        A = np.matmul(np.matmul(M_1,A),M)
        B = np.matmul(B,M)

    polynomial_param = [1]
    for i in range(0,n):
        polynomial_param.append((-1)*A[0,i])
    eig = np.roots(polynomial_param)
    eig = np.sort(eig)[::-1]

    eigvect = []
    for i in range (0,n):
        temp = []
        for j in range (0,n):
            temp.append(eig[i]**(n-j-1))
        eigvect.append(eigenvector(n,B,np.array(temp)))
        # chuẩn hoá về vector đơn vị
        eigvect[i] = eigvect[i]/np.linalg.norm(eigvect[i])
    eigvect = np.array(eigvect)
    return eig, np.transpose(eigvect)

#-------------------------------------------------
(row,col) = A.shape
ATA = np.transpose(A)@A # tính V = col x col
diag, V = eigenvalue_decomposition(ATA)
delta = np.sqrt(diag)
U = []
D = np.zeros(A.shape)
for i in range(min(row,col)):
    D[i,i] = delta[i]
    U.append(A@V[:,i]/delta[i])

AAT = A@np.transpose(A) # tính U = row x row
diag_1, U_temp = eigenvalue_decomposition(AAT)
for i in range(col,row):
    U.append(U_temp[:,i])
U = np.array(U)
U = np.transpose(U)

check = U@D@np.transpose(V)
print(U)
print(D)
print(np.transpose(V))
print(check)
print(np.allclose(A,check))