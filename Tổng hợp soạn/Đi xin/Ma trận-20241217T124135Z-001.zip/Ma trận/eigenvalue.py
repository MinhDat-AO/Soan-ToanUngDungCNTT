import numpy as np

def eig(matran):
    val,vec = np.linalg.eig(matran)
    return val,vec

def main():
    A = np.array([
        [2,1,0],
        [1,3,1],
        [0,1,2]
    ])
    a,b = eig(A)
    print(a)
    print(b)
    # diag = np.zeros(A.shape)
    # for i in range (0,n):
    #     diag[i][i]=t[i]
    # V = np.column_stack(b)
    # V_ = np.linalg.inv(V)
    # print(A)
    # print("=")
    # print(V)
    # print(diag)
    # print(V_)

    # T = np.matmul(V,diag)
    # T = np.dot(diag,V_)
    # print(T)
main()