#include <bits/stdc++.h>
#define ll long long
#define endl '\n'
#define pll pair<long long,long long>
#define int long long
#define pii pair<int,int>
#define FOR(i,a,b) for(int i =a; i<=b; i++)
#define ROF(i,a,b) for(int i =a; i>=b; i--)

long long MOD = 1e9+7;

using namespace std;
long long d, x, y;
void extendedEuclid(int A, int B) {
    if(B == 0) {
        d = A;
        x = 1;
        y = 0;
    }
    else {
        extendedEuclid(B, A%B);
        long long temp = x;
        x = y;
        y = temp - (A/B)*y;
    }
}
int inv(int A, int M)
{
    MOD = M;
    extendedEuclid(A,MOD);
    return (x%MOD+MOD)%MOD;
}
int M[100];
int a[100];
void solve(){   
    cout<<"Nhap he phuong trinh, nhap so phuong trinh (n):\n";
    int n;
    cin>>n;
    cout<<"Cac dong tiep theo nhap ai, Mi\n";
    for (int i =1; i<=n; i++){
        cin>>a[i]>>M[i];
    }  
    int MM=1;
    for (int i =1; i<=n; i++){
        MM*=M[i];
    }
    int result=0;
    for (int i =1; i<=n; i++){
        int Md = MM/M[i];
        (x+=a[i]*Md*inv(Md,M[i]))%=MM;
    }
    cout<<result<<endl;
}

int32_t main(){
    solve();
    return 0;
}