import numpy as np

def calculate_delta(c, a, X, n):
    delta = np.zeros(n + 1)
    for i in range(1, n + 1):
        temp = 0
        for j in range(1, m + 1):
            k = X[j]
            temp += c[k] * a[j][i]
        delta[i] = temp - c[i]
    return delta

def fx(c, b, X):
    temp = 0
    for i in range(1, m + 1):
        j = X[i]
        temp += c[j] * b[i]
    return temp

def step_to_step(c, a, b, X, delta, n):
    for i in range(1, m + 1):
        k = X[i]
        print(f'{c[k]:<10} X{k:<10} {b[i]:<10}', end=' ')
        for j in range(1, n + 1):
            print(f'{a[i][j]:<10}', end=' ')
        print()
    print(' ' * 23, end='')
    print(f'{fx(c, b, X):<10}', end=' ')
    for i in range(1, n + 1):
        print(f'{delta[i]:<10}', end=' ')
    print()

def check_delta(delta, n):
    return all(val <= 0 for val in delta[1:])

def check_solution(a, delta, n):
    for i in range(1, n + 1):
        if delta[i] > 0:
            for j in range(1, m + 1):
                if a[j][i] > 0:
                    return False
            return True

def find_Xs(delta, n):
    max_index = 0
    for i in range(1, n + 1):
        if delta[i] > 0:
            max_index = i
            for j in range(i + 1, n + 1):
                if delta[j] > 0:
                    if delta[max_index] < delta[j]:
                        max_index = j
    return max_index

def find_Xr(b, a, Xs):
    min_index = 0
    for i in range(1, m + 1):
        if a[i][Xs] > 0:
            min_index = i
            for j in range(1, m + 1):
                if a[j][Xs] > 0:
                    if (b[min_index] / a[min_index][Xs]) > (b[j] / a[j][Xs]):
                        min_index = j
    return min_index

def update(a, b, X, s, r, a_new, b_new, n):
    for i in range(1, m + 1):
        if i != r:
            b_new[i] = b[i] - (b[r] / a[r][s]) * a[i][s]
        else:
            b_new[i] = b[r] / a[r][s]

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if i != r:
                a_new[i][j] = a[i][j] - (a[r][j] / a[r][s]) * a[i][s]
            else:
                a_new[i][j] = a[r][j] / a[r][s]

def simplex_method(c, a, b, X, delta, n, a_new_phase, b_new_phase):
    calculate_delta(c, a, X, delta, n)
    fx_value = fx(c, b, X)
    step_to_step(c, a, b, X, delta, n)

    if check_delta(delta, n):
        print(f'Min fx = {fx_value}')
        return
    elif check_solution(a, delta, n):
        print('No solution !!!')
        return
    else:
        Xs = find_Xs(delta, n)
        Xr = find_Xr(b, a, Xs)
        X[Xr] = Xs
        a_new = np.zeros((m + 1, MAX_SIZE))
        b_new = np.zeros(m + 1)
        update(a, b, X, Xs, Xr, a_new, b_new, n)
        for i in range(1, m + 1):
            for j in range(1, n + 1):
                a_new_phase[i][j] = a_new[i][j]
        for i in range(1, m + 1):
            b_new_phase[i] = b_new[i]
        simplex_method(c, a_new, b_new, X, delta, n, a_new_phase, b_new_phase)

def two_phase_method(c, a, b):
    c_phase1 = np.concatenate(([0], np.ones(n + m)))
    X = np.arange(n + 1, n + m + 1)
    a_phase1 = np.zeros((m + 1, MAX_SIZE))
    for i in range(1, m + 1):
        for j in range(1, n + m + 1):
            if j <= n:
                a_phase1[i][j] = a[i][j]
            elif j == n + i:
                a_phase1[i][j] = 1
            else:
                a_phase1[i][j] = 0

    delta_phase1 = np.zeros(n + m + 1)
    a_new_phase1 = np.zeros((m + 1, MAX_SIZE))
    b_new_phase1 = np.zeros(m + 1)
    simplex_method(c_phase1, a_phase1, b, X, delta_phase1, n + m, a_new_phase1, b_new_phase1)

    a_phase2 = np.zeros((m + 1, MAX_SIZE))
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if j <= n:
                a_phase2[i][j] = a_new_phase1[i][j]

    delta2 = np.zeros(n + 1)
    a_new_phase2 = np.zeros((m + 1, MAX_SIZE))
    b_new_phase2 = np.zeros(m + 1)
    simplex_method(c, a_phase2, b_new_phase1, X, delta2, n, a_new_phase2, b_new_phase2)

if __name__ == "__main__":
    MAX_SIZE = 100

    n, m = (5,3)

    c = [0,-1, -2, 1, 0, 0] 

    a = np.array([[0, 0, 0, 0, 0, 0],[0,-1, 4, -2, 1, 0],
                [0,1, 1 ,2, 0, -1],
                [0,2, -1, 2, 0, 0]])
    b = [0] + [6, 6, 4]
    
    two_phase_method(c, a, b)
