def phi(a):
    i = 2
    res = a
    while (True):
        tmp =0
        while(a%i==0): 
            a/=i
            tmp = i
        if tmp != 0: res = res//tmp*(tmp-1)
        i+=1
        if (i>1e6): break
    if (a!=1): res = res //a * (a-1)
    return res

a = int(input())
print(phi(a))