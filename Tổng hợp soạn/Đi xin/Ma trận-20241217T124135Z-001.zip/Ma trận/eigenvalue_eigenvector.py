import numpy as np

A = np.array([
    [1,2,3],
    [2,3,4],
    [3,4,5]
])

n = A.shape[0]

B = np.eye(n)
M = np.zeros(A.shape)
M_1 = np.zeros(A.shape)
for k in range(n-2,-1,-1):
    for i in range(0,n):
        for j in range(0,n):
            if (i!=k):
                if (i==j):
                    M[i,j] = 1
                    M_1[i,j] = 1
                else:
                    M[i,j] = 0
                    M_1[i,j] = 0
            else:
                M_1[i,j] = A[k+1,j]
                if (j==k):
                    M[i,j] = 1/A[k+1,k]
                else:
                    M[i,j] = -A[k+1,j]/A[k+1,k]
    A = M_1@A@M
    B = (B@M)

dt = [1]
for i in range(0,n):
    dt.append((-1)*A[0,i])
eigv = np.roots(dt)
print("Trị riêng")
print(eigv)
# hàm tính vector riêng
def eigenvector(n, B, inp):
    res = []
    for i in range(0,n):
        sum = 0
        for j in range(0,n):
            sum += B[i,j]*inp[j]
        res.append(sum)
    return np.array(res)

#vector riêng:
print("Vector Riêng")
eigvect = []
for i in range (0,n):
    temp = []
    for j in range (0,n):
        temp.append(eigv[i]**(n-j-1))
    eigvect.append(eigenvector(n,B,np.array(temp)))
eigvect = np.array(eigvect)
print(eigvect)