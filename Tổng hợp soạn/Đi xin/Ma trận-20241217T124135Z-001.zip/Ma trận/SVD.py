import numpy as np


def eigenvector(n, B, inp):
    # hàm trả về Vector riêng tương ứng với trị riêng
    # n là kích thước ma trận vuông, B là ma trận vuông, inp là danh sách x^n, x^(n-1) ...
    # Sử dụng phương pháp danhilevski
    res = []
    for i in range(0,n):
        sum = 0
        for j in range(0,n):
            sum += B[i,j]*inp[j]
        res.append(sum)
    return np.array(res)

def eigs(A):
    # Hàm trả về trị riêng và vector riêng sử dụng phương pháp danhilevski
    n = A.shape[0]
    B = np.zeros(A.shape)
    for i in range (0,n):
        B[i,i] = 1
    for k in range(n-2,-1,-1):
        M = np.zeros(A.shape)
        M_1 = np.zeros(A.shape)
        for i in range(0,n):
            for j in range(0,n):
                if (i!=k):
                    if (i==j):
                        M[i,j] = 1
                        M_1[i,j] = 1
                    else:
                        M[i,j] = 0
                        M_1[i,j] = 0
                else:
                    M_1[i,j] = A[k+1,j]
                    if (j==k):
                        M[i,j] = 1/A[k+1,k]
                    else:
                        M[i,j] = -A[k+1,j]/A[k+1,k]
        A = M_1@A@M
        B = B@M
    dt = [1]
    for i in range(0,n):
        dt.append((-1)*A[0,i])
    eig = np.roots(dt)
    eigvect = []
    for i in range (0,n):
        temp = []
        for j in range (0,n):
            temp.append(eig[i]**(n-j-1))
        eigvect.append(eigenvector(n,B,np.array(temp)))
    eigvect = np.array(eigvect)
    eigvect = eigvect.transpose()
    return eig,eigvect

def decom(A):
    # Hàm phân rã trị riêng, vector riêng
    n,m = A.shape
    diag = np.zeros(A.shape)
    eigval,eigvec = eigs(A)
    # Lấy ma trận riêng, vector riêng của ma trận vuông A
    for i in range (0,n):
        diag[i][i]=np.sqrt(eigval[i])
        # Gán giá trị riêng vào ma trận chéo hoá, lấy căn bậc 2 tương ứng 
    U = eigvec
    U_ = np.linalg.inv(U)
    return U,diag,U_
    

def main():
    A = np.array([
        [9,5,3],
        [11,11,11],
        [3,5,9]
    ])
    AAT = A.transpose()@A
    ATA = A@A.transpose()
    n,m = A.shape
    U,diag,U_ = decom(AAT)
    # Phân rã ma trận A*AT
    V,diagt,V_ = decom(ATA)
    # Phân rã ma trận AT*T để lấy VT
    print(U)
    print(diag)
    print(V.transpose())
    SVD = np.linalg.svd(A)
    print(SVD)
main()