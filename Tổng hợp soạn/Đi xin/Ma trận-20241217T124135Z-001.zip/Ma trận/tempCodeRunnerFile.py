import numpy as np

a = np.array(
    [[1,2,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [2,5,2,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,2,5,2,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,2,5,2,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,2,5,2,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,2,5,2,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,2,5,2,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,2,5,2,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,2,5,2,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,2,5,2,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,2,5,2,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,2,5,2,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,2,5,2,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,2,5,2],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,2,5],])

def ok():
    # kiểm tra các điều kiện của ma trận 
    p = True
    eigenvals = np.linalg.eigvals(a) 
    # lấy danh sách trị riêng
    if (eigenvals<=0).any():
        # kiểm tra ma trận xác định dương
        p =False
    if (np.transpose(a)!=a).any():
        # kiểm tra ma trận có phải là ma trận đối xứng
        p =False
    return p

def main():
    if not ok():
        print("Ma trận không thể tính")
        return
    l = np.zeros(a.shape)
    n = a.shape[1]
    for i in range(0,n):
        # duyệt từ 0 -> n-1 (ma trận bắt đầu từ (0,0))
        for j in range(0,i+1):
            if i == j:
                # trường hợp các phần tử trên đường chéo chính
                sum = 0
                for k in range(0,j):
                    sum+=l[i][k]**2
                sum = a[i][j]-sum
                l[i][j] = np.sqrt(sum)
            else:
                # trường hợp còn lại
                sum = 0
                for k in range(0,j):
                    sum += l[i][k]*l[j][k]
                sum = a[i][j]-sum
                l[i][j] = 1/l[j][j]*sum
    print(l)
    print(l.transpose())
    if (l == np.linalg.cholesky(a)).all():
        # kiểm tra liệu kết quả có đúng với hàm mặc định thư viện
        print("Ok")

main()