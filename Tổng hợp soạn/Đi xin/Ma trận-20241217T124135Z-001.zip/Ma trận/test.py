import numpy as np

# Tạo ma trận vuông A (ví dụ)
A = np.array([
    [-1,3],
    [-2,4]])

# Tính giá trị riêng và vector riêng
eigenvalues, eigenvectors = np.linalg.eig(A)

# Chọn một trị riêng cụ thể (ví dụ: trị riêng đầu tiên)
tririenng_cu_the = eigenvalues[0]

# Tìm vector riêng ứng với trị riêng cụ thể
index = np.where(eigenvalues == tririenng_cu_the)[0][0]
vector_rieng_ung_voi_tririenng = eigenvectors[:, index]

print("Trị riêng cụ thể:", tririenng_cu_the)
print("Vector riêng ứng với trị riêng cụ thể:")
print(vector_rieng_ung_voi_tririenng)
