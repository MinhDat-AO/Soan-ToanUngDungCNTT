import numpy as np

a = np.array([
    [6, 15, 55], 
     [15, 55, 225],
     [55, 225, 979]
])

def ok():
    p = True
    eigenvals = np.linalg.eigvals(a) 
    if (eigenvals<=0).any():
        p =False
    if (np.transpose(a)!=a).any():
        p =False
    return p

def main():
    if not ok():
        print("I'm not ok")
        return
    print(np.linalg.cholesky(a))
    l = np.zeros(a.shape)
    n = a.shape[1]
    for i in range(0,n):
        for j in range(0,i+1):
            if i == j:
                sum = 0
                for k in range(0,j):
                    sum+=l[i][k]**2
                sum = a[i][j]-sum
                l[i][j] = np.sqrt(sum)
            else:
                sum = 0
                for k in range(0,j):
                    sum += l[i][k]*l[j][k]
                sum = a[i][j]-sum
                l[i][j] = 1/l[j][j]*sum

    print(l)
    if (l == np.linalg.cholesky(a)).all():
        print("Ok")

main()